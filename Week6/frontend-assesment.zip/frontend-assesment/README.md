#Assement

Used Tools n libraries
React,Axios

React features
useEffect,useState
